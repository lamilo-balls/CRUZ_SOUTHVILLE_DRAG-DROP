"""Pure math for Lab 2 (no OpenCV needed, so it can be unit-tested anywhere)."""
import math
from collections import namedtuple

Bounds = namedtuple("Bounds", "L R T B")
Overlap = namedtuple("Overlap", "w h area pct")


def distance(x1, y1, x2, y2):
    return math.hypot(x2 - x1, y2 - y1)


def rect_bounds(cx, cy, w, h):
    return Bounds(cx - w / 2, cx + w / 2, cy - h / 2, cy + h / 2)


def point_in_bounds(px, py, b):
    return b.L <= px <= b.R and b.T <= py <= b.B


def intersection(b1, b2):
    wi = max(0.0, min(b1.R, b2.R) - max(b1.L, b2.L))
    hi = max(0.0, min(b1.B, b2.B) - max(b1.T, b2.T))
    area = wi * hi
    a1 = (b1.R - b1.L) * (b1.B - b1.T)
    a2 = (b2.R - b2.L) * (b2.B - b2.T)
    smaller = min(a1, a2)
    pct = 100.0 * area / smaller if smaller > 0 else 0.0
    return Overlap(wi, hi, area, pct)


def clamp_center(cx, cy, w, h, W, H):
    cx = W / 2 if w >= W else min(max(cx, w / 2), W - w / 2)
    cy = H / 2 if h >= H else min(max(cy, h / 2), H - h / 2)
    return cx, cy


def grid_snap(x, y, g):
    if g <= 0:
        return x, y, 0.0
    xs = g * math.floor(x / g + 0.5)
    ys = g * math.floor(y / g + 0.5)
    return xs, ys, distance(x, y, xs, ys)


def grid_cell(x, y, g):
    return (int(x // g), int(y // g)) if g > 0 else (0, 0)


class MotionTracker:
    def __init__(self, alpha=0.4, max_gap=0.5, min_dt=1e-3):
        self.alpha, self.max_gap, self.min_dt = alpha, max_gap, min_dt
        self.reset()

    def reset(self):
        self.prev_pos = None
        self.prev_t = None
        self.dx = self.dy = self.dt = 0.0
        self.raw_vx = self.raw_vy = 0.0
        self.vx = self.vy = 0.0
        self.speed = 0.0
        self.ax = self.ay = self.acc = 0.0
        self.gap_flag = False

    def update(self, x, y, t):
        self.gap_flag = False
        if self.prev_pos is None:
            self.prev_pos, self.prev_t = (x, y), t
            return
        dt = t - self.prev_t
        if dt < self.min_dt:          
            return
        if dt > self.max_gap:         
            self.reset()
            self.prev_pos, self.prev_t = (x, y), t
            self.gap_flag = True
            return
        self.dx, self.dy, self.dt = x - self.prev_pos[0], y - self.prev_pos[1], dt
        self.raw_vx, self.raw_vy = self.dx / dt, self.dy / dt
        svx = self.alpha * self.raw_vx + (1 - self.alpha) * self.vx
        svy = self.alpha * self.raw_vy + (1 - self.alpha) * self.vy
        self.ax, self.ay = (svx - self.vx) / dt, (svy - self.vy) / dt
        self.acc = math.hypot(self.ax, self.ay)
        self.vx, self.vy = svx, svy
        self.speed = math.hypot(svx, svy)
        self.prev_pos, self.prev_t = (x, y), t


class PinchDetector:
    def __init__(self, grab_th=40.0, release_th=60.0):
        assert release_th > grab_th, "release threshold must be larger than grab threshold"
        self.grab_th, self.release_th = grab_th, release_th
        self.pinching = False

    def update(self, d):
        if not self.pinching and d <= self.grab_th:
            self.pinching = True
        elif self.pinching and d >= self.release_th:
            self.pinching = False
        return self.pinching

def calculate_spring_force(x, y, tx, ty, k=2.0, rest_length=0.0):
    dx, dy = tx - x, ty - y
    dist = math.hypot(dx, dy)
    if dist == 0:
        return 0.0, 0.0
    force = k * (dist - rest_length)
    return (dx / dist) * force, (dy / dist) * force

def calculate_attraction_repulsion(x, y, tx, ty, strength, min_dist=20.0):
    dx, dy = tx - x, ty - y
    dist = math.hypot(dx, dy)
    clamped_dist = max(dist, min_dist) 
    force = strength / (clamped_dist * clamped_dist)
    if dist == 0:
        return 0.0, 0.0
    return (dx / dist) * force, (dy / dist) * force

def semi_implicit_euler(x, y, vx, vy, fx, fy, mass, dt, damping=0.98):
    ax, ay = fx / mass, fy / mass
    vx = (vx + ax * dt) * damping
    vy = (vy + ay * dt) * damping
    x = x + vx * dt
    y = y + vy * dt
    return x, y, vx, vy