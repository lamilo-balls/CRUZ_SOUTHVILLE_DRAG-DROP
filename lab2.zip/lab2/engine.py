"""State machine + object logic for Lab 2 (no OpenCV, fully testable)."""
import math
import random
from dataclasses import dataclass
from enum import Enum

from geometry import (MotionTracker, PinchDetector, clamp_center, distance,
                      grid_cell, grid_snap, intersection, point_in_bounds,
                      rect_bounds, Overlap, calculate_spring_force,
                      calculate_attraction_repulsion, semi_implicit_euler)


class State(Enum):
    IDLE = "IDLE"
    HOVER = "HOVER"
    GRABBED = "GRABBED"
    DRAGGING = "DRAGGING"
    RELEASED = "RELEASED"
    INVALID = "INVALID"
    COLLISION = "COLLISION"


DRAG_STATES = (State.GRABBED, State.DRAGGING, State.COLLISION)


@dataclass
class Config:
    grab_th: float = 40.0          
    release_th: float = 60.0       
    cell: int = 50                 
    snap_on: bool = True
    snap_max_error: float = 30.0   
    dwell_time: float = 1.5        
    dwell_speed: float = 40.0      
    hand_loss_grace: float = 0.4   
    invalid_hold: float = 0.6      
    max_overlap_pct: float = 0.0   
    max_gap: float = 0.5           
    max_rects: int = 8
    create_debounce: float = 0.3   
    gravity: float = 980.0
    spring_k: float = 5.0
    attractor_strength: float = 0.0
    damping: float = 0.95
    mass_base: float = 1.0
    physics_enabled: bool = False


class Rect:
    def __init__(self, rid, cx, cy, w, h):
        self.id, self.cx, self.cy, self.w, self.h = rid, cx, cy, w, h
        self.locked = False
        self.vx = 0.0
        self.vy = 0.0
        self.fx = 0.0
        self.fy = 0.0
        self.mass = (w * h) / 10000.0
        self.ke = 0.0

    def bounds(self):
        return rect_bounds(self.cx, self.cy, self.w, self.h)


GRID_SIZES = (20, 25, 40, 50, 60, 80, 100)


class DragEngine:
    def __init__(self, cfg=None):
        self.cfg = cfg or Config()
        self.rects, self.next_id = [], 1
        self.state, self.selected, self.hover = State.IDLE, None, None
        self.pinch = PinchDetector(self.cfg.grab_th, self.cfg.release_th)
        self.prev_pinch = False
        self.motion = MotionTracker(max_gap=self.cfg.max_gap)
        self.cursor = self.thumb = None
        self.pinch_d = None
        self.offset, self.start_pos = (0.0, 0.0), None
        self.dwell_enter, self.t_dwell = None, 0.0
        self.snap_err, self.grid_cell = 0.0, None
        self.overlap, self.overlap_with = Overlap(0, 0, 0, 0), None
        self.lost_since, self.invalid_until = None, 0.0
        self.message, self.message_until = "", 0.0
        self.last_create = -1e9
        self.events, self.t0 = [], None
        self.W, self.H = 1280, 720

    @property
    def focus(self):
        return self.selected or self.hover

    def say(self, msg, now, dur=1.5):
        self.message, self.message_until = msg, now + dur

    def _set(self, new, now, why=""):
        if new != self.state:
            t = now - (self.t0 if self.t0 is not None else now)
            self.events.append((t, self.state.value, new.value, why))
            self.state = new

    def save_log(self, path):
        with open(path, "w") as f:
            f.write("time_s,from,to,detail\n")
            for t, a, b, why in self.events:
                f.write(f"{t:.2f},{a},{b},{why}\n")

    def topmost_at(self, x, y):
        for r in reversed(self.rects):        
            if point_in_bounds(x, y, r.bounds()):
                return r
        return None

    def _max_overlap(self, r):
        best, other = Overlap(0, 0, 0, 0), None
        b = r.bounds()
        for o in self.rects:
            if o is r:
                continue
            ov = intersection(b, o.bounds())
            if ov.pct > best.pct:
                best, other = ov, o
        return best, other

    def add_rect(self, now, rng=random):
        if now - self.last_create < self.cfg.create_debounce:
            return None                        
        self.last_create = now
        if len(self.rects) >= self.cfg.max_rects:
            self.say("Max rectangles reached", now)
            return None
        for _ in range(80):
            w, h = rng.randint(80, 140), rng.randint(80, 140)
            cx = rng.uniform(w / 2, self.W - w / 2)
            cy = rng.uniform(h / 2, self.H - h / 2)
            cand = Rect(self.next_id, cx, cy, w, h)
            if all(intersection(cand.bounds(), o.bounds()).area == 0 for o in self.rects):
                self.rects.append(cand)
                self.next_id += 1
                return cand
        self.say("No free space for a new rectangle", now)
        return None

    def toggle_snap(self, now):
        self.cfg.snap_on = not self.cfg.snap_on
        self.say(f"Snap {'ON' if self.cfg.snap_on else 'OFF'}", now)

    def change_cell(self, step, now):
        i = GRID_SIZES.index(self.cfg.cell) if self.cfg.cell in GRID_SIZES else 3
        self.cfg.cell = GRID_SIZES[min(max(i + step, 0), len(GRID_SIZES) - 1)]
        self.say(f"Grid cell = {self.cfg.cell}px", now)

    def unlock_all(self, now):
        for r in self.rects:
            r.locked = False
        self.say("All rectangles unlocked", now)

    def update(self, sample, now, W, H):
        c = self.cfg
        self.W, self.H = W, H
        if self.t0 is None:
            self.t0 = now
        if self.state == State.RELEASED:
            self._set(State.IDLE, now)
        if sample is None:
            self._hand_lost(now)
            return
        self.lost_since = None
        ix, iy, tx, ty = sample
        self.cursor, self.thumb = (ix, iy), (tx, ty)
        self.pinch_d = distance(ix, iy, tx, ty)
        pinching = self.pinch.update(self.pinch_d)
        rising = pinching and not self.prev_pinch      
        self.prev_pinch = pinching
        self.motion.update(ix, iy, now)
        if self.motion.gap_flag:
            self.dwell_enter, self.t_dwell = None, 0.0
            self.say("Large frame gap - motion reset", now)

        if self.state == State.INVALID:                
            if now >= self.invalid_until:
                self._set(State.IDLE, now)
            else:
                return

        if self.state in (State.IDLE, State.HOVER):
            hit = self.topmost_at(ix, iy)
            self.hover = hit
            self._set(State.HOVER if hit else State.IDLE, now,
                      f"R{hit.id}" if hit else "")
            if rising and hit:
                if hit.locked:
                    self.say(f"R{hit.id} is LOCKED (press u to unlock)", now)
                else:
                    self._grab(hit, ix, iy, now)
            return

        r = self.selected
        if r is None:
            self._set(State.IDLE, now)
            return
        if not pinching:
            self._finish_drop(now, "pinch released")
            return
        r.cx, r.cy = clamp_center(ix - self.offset[0], iy - self.offset[1], r.w, r.h, W, H)
        self.overlap, self.overlap_with = self._max_overlap(r)
        self._set(State.COLLISION if self.overlap.pct > 0 else State.DRAGGING, now,
                  f"overlap {self.overlap.pct:.0f}%")
        _, _, self.snap_err = grid_snap(r.cx, r.cy, c.cell)
        self.grid_cell = grid_cell(r.cx, r.cy, c.cell)

        stable = self.motion.speed < c.dwell_speed and not self.motion.gap_flag
        if stable and self.overlap.pct == 0:
            if self.dwell_enter is None:
                self.dwell_enter = now
            self.t_dwell = now - self.dwell_enter          
            if self.t_dwell >= c.dwell_time:
                self._finish_drop(now, "dwell lock", lock=True)
        else:
            self.dwell_enter, self.t_dwell = None, 0.0

        if self.motion.dt > 0 and not self.motion.gap_flag and c.physics_enabled:
            dt = min(self.motion.dt, 0.05)
            
            for i, p_rect in enumerate(self.rects):
                if p_rect is self.selected or p_rect.locked:
                    p_rect.vx, p_rect.vy, p_rect.ke = 0, 0, 0
                    continue

                p_rect.fx, p_rect.fy = 0.0, 0.0
                p_rect.fy += c.gravity * p_rect.mass

                if self.cursor and c.attractor_strength != 0:
                    afx, afy = calculate_attraction_repulsion(
                        p_rect.cx, p_rect.cy, self.cursor[0], self.cursor[1], c.attractor_strength
                    )
                    p_rect.fx += afx * p_rect.mass
                    p_rect.fy += afy * p_rect.mass
                
                if self.cursor and self.hover is p_rect and c.spring_k > 0:
                    sfx, sfy = calculate_spring_force(p_rect.cx, p_rect.cy, self.cursor[0], self.cursor[1], c.spring_k)
                    p_rect.fx += sfx
                    p_rect.fy += sfy

                p_rect.cx, p_rect.cy, p_rect.vx, p_rect.vy = semi_implicit_euler(
                    p_rect.cx, p_rect.cy, p_rect.vx, p_rect.vy, p_rect.fx, p_rect.fy, p_rect.mass, dt, c.damping
                )
                
                if p_rect.cx - p_rect.w/2 < 0: p_rect.cx, p_rect.vx = p_rect.w/2, -p_rect.vx * 0.7
                if p_rect.cx + p_rect.w/2 > W: p_rect.cx, p_rect.vx = W - p_rect.w/2, -p_rect.vx * 0.7
                if p_rect.cy - p_rect.h/2 < 0: p_rect.cy, p_rect.vy = p_rect.h/2, -p_rect.vy * 0.7
                if p_rect.cy + p_rect.h/2 > H: p_rect.cy, p_rect.vy = H - p_rect.h/2, -p_rect.vy * 0.7

                for other in self.rects[i+1:]:
                    if other is self.selected: continue
                    ov = intersection(p_rect.bounds(), other.bounds())
                    if ov.area > 0:
                        dx, dy = p_rect.cx - other.cx, p_rect.cy - other.cy
                        dist = math.hypot(dx, dy)
                        if dist > 0:
                            push = 200.0 / dist
                            p_rect.vx += (dx/dist) * push
                            p_rect.vy += (dy/dist) * push
                            other.vx -= (dx/dist) * push
                            other.vy -= (dy/dist) * push

                speed_sq = p_rect.vx**2 + p_rect.vy**2
                p_rect.ke = 0.5 * p_rect.mass * speed_sq

    def _grab(self, r, ix, iy, now):
        self.selected = r
        self.offset = (ix - r.cx, iy - r.cy)
        self.start_pos = (r.cx, r.cy)
        self.rects.remove(r)
        self.rects.append(r)                   
        self.dwell_enter, self.t_dwell = None, 0.0
        self._set(State.GRABBED, now, f"R{r.id}")

    def _finish_drop(self, now, why, lock=False):
        r, c = self.selected, self.cfg
        if c.snap_on:
            xs, ys, err = grid_snap(r.cx, r.cy, c.cell)
            self.snap_err = err
            if err <= c.snap_max_error:
                r.cx, r.cy = clamp_center(xs, ys, r.w, r.h, self.W, self.H)
            else:
                self.say(f"Snap error {err:.0f}px too large - not snapped", now)
        ov, other = self._max_overlap(r)
        self.overlap, self.overlap_with = ov, other
        if ov.pct > c.max_overlap_pct:         
            r.cx, r.cy = self.start_pos
            self.invalid_until = now + c.invalid_hold
            self._set(State.INVALID, now, f"{why}: {ov.pct:.0f}% overlap with R{other.id}")
            self.say("INVALID DROP - returned to start", now, c.invalid_hold)
        else:
            if lock:
                r.locked = True
                self.say(f"R{r.id} LOCKED", now)
            self._set(State.RELEASED, now, why + (" + locked" if lock else ""))
        self.selected = None
        self.dwell_enter, self.t_dwell = None, 0.0

    def _hand_lost(self, now):
        if self.lost_since is None:
            self.lost_since = now
        self.cursor = self.thumb = self.pinch_d = None
        self.motion.reset()
        self.dwell_enter, self.t_dwell = None, 0.0
        if self.state in DRAG_STATES:
            if now - self.lost_since >= self.cfg.hand_loss_grace:
                self._finish_drop(now, "hand lost")
                self.pinch.pinching = self.prev_pinch = False
            else:
                self.say("Hand lost - holding...", now, 0.3)
            return
        if self.state == State.INVALID and now >= self.invalid_until:
            self._set(State.IDLE, now)
        elif self.state == State.HOVER:
            self._set(State.IDLE, now, "hand lost")
        self.hover = None if self.state == State.IDLE else self.hover
        self.pinch.pinching = self.prev_pinch = False