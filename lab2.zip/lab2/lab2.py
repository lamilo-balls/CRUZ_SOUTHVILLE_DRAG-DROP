print("Starting Lab 2...")

"""Lab 2 (V08) - Multi-Force Interactive Physics Engine (OpenCV + CVZone).
Keys: p=physics  1=gravity  2=forcefield  3=damping  c=new rectangle  g=snap  [ ]=grid size  u=unlock  s=screenshot  q=quit
"""
import os
import sys
import time
import math

import cv2

try:
    from cvzone.HandTrackingModule import HandDetector
except Exception as e:
    print("Could not import cvzone/mediapipe:", e)
    print("Run: pip install -r requirements.txt")
    sys.exit(1)

from engine import DragEngine, State
from geometry import rect_bounds

STATE_COLORS = {            
    State.IDLE: (255, 0, 255), State.HOVER: (0, 255, 255),
    State.GRABBED: (0, 165, 255), State.DRAGGING: (255, 200, 0),
    State.COLLISION: (0, 0, 255), State.INVALID: (0, 0, 160),
    State.RELEASED: (0, 255, 0),
}
BASE_COLOR, LOCK_COLOR = (255, 0, 255), (120, 120, 120)


def open_camera(indices=(0, 1, 2, 3)):
    for i in indices:
        cap = cv2.VideoCapture(i)
        if cap.isOpened():
            cap.set(3, 1280)
            cap.set(4, 720)
            ok, _ = cap.read()
            if ok:
                return cap, i
        cap.release()
    return None, None


def extract_sample(hands, W, H):
    if not hands:
        return None
    lm = hands[0].get("lmList")
    if lm is None or len(lm) < 21:
        return None
    ix, iy, tx, ty = lm[8][0], lm[8][1], lm[4][0], lm[4][1]
    if not (0 <= ix < W and 0 <= iy < H):
        return None
    return ix, iy, tx, ty


def put(img, text, org, color=(255, 255, 255), scale=0.5, thick=1):
    cv2.putText(img, text, org, cv2.FONT_HERSHEY_SIMPLEX, scale, color, thick, cv2.LINE_AA)


def draw(img, eng, now, fps):
    H, W = img.shape[:2]
    c = eng.cfg
    if c.snap_on:                                           
        for x in range(0, W, c.cell):
            cv2.line(img, (x, 0), (x, H), (80, 80, 80), 1)
        for y in range(0, H, c.cell):
            cv2.line(img, (0, y), (W, y), (80, 80, 80), 1)

    overlay = img.copy()
    for r in eng.rects:
        b = rect_bounds(r.cx, r.cy, r.w, r.h)
        col = LOCK_COLOR if r.locked else BASE_COLOR
        if r is eng.focus and not r.locked:
            col = STATE_COLORS[eng.state]
        cv2.rectangle(overlay, (int(b.L), int(b.T)), (int(b.R), int(b.B)), col, cv2.FILLED)
    cv2.addWeighted(overlay, 0.45, img, 0.55, 0, dst=img)

    for r in eng.rects:
        b = rect_bounds(r.cx, r.cy, r.w, r.h)
        p1, p2 = (int(b.L), int(b.T)), (int(b.R), int(b.B))
        col = LOCK_COLOR if r.locked else BASE_COLOR
        if r is eng.focus and not r.locked:
            col = STATE_COLORS[eng.state]
        cv2.rectangle(img, p1, p2, col, 2)
        put(img, f"R{r.id}" + (" LOCK" if r.locked else ""), (p1[0] + 6, p1[1] + 20), scale=0.6, thick=2)
        if r is eng.selected:                               
            cv2.rectangle(img, (p1[0] - 6, p1[1] - 6), (p2[0] + 6, p2[1] + 6), (255, 255, 255), 3)
            frac = min(eng.t_dwell / c.dwell_time, 1.0)     
            cv2.rectangle(img, (p1[0], p1[1] - 18), (p2[0], p1[1] - 10), (60, 60, 60), cv2.FILLED)
            cv2.rectangle(img, (p1[0], p1[1] - 18), (p1[0] + int((p2[0] - p1[0]) * frac), p1[1] - 10),
                          (0, 255, 0), cv2.FILLED)
            put(img, f"dwell {eng.t_dwell:.1f}/{c.dwell_time:.1f}s", (p1[0], p1[1] - 24), scale=0.45)

    if eng.cursor:                                          
        cx, cy = map(int, eng.cursor)
        tx, ty = map(int, eng.thumb)
        pinching = eng.pinch.pinching
        cv2.line(img, (cx, cy), (tx, ty), (0, 255, 0) if pinching else (255, 255, 255), 2)
        cv2.circle(img, (cx, cy), 10, (0, 255, 0) if pinching else (0, 255, 255), cv2.FILLED)

    f = eng.focus
    lines = [f"FPS {fps:4.1f}   STATE: {eng.state.value}",
             f"Selected: {'R%d' % eng.selected.id if eng.selected else '-'}   "
             f"Focus: {'R%d' % f.id if f else '-'}"]
    if f:
        b = f.bounds()
        lines.append(f"L{b.L:.0f} R{b.R:.0f} T{b.T:.0f} B{b.B:.0f}")
        if eng.cfg.physics_enabled and not f.locked and f is not eng.selected:
            f_net = math.hypot(f.fx, f.fy)
            lines.append(f"Physics -> Mass: {f.mass:.2f}  KE: {f.ke:.0f} J")
            lines.append(f"Net Force: {f_net:.0f}N  Acc: {(f_net/f.mass if f.mass>0 else 0):.0f}px/s^2")
    if eng.cursor:
        cd = f"{__import__('math').hypot(eng.cursor[0]-f.cx, eng.cursor[1]-f.cy):.1f}" if f else "-"
        lines.append(f"Cursor ({eng.cursor[0]:.0f},{eng.cursor[1]:.0f})  dist->center {cd}px")
    else:
        lines.append("Cursor: NO HAND")
    m = eng.motion
    lines += [f"dx {m.dx:+.1f} dy {m.dy:+.1f}  dt {m.dt*1000:.1f}ms",
              f"v ({m.vx:+.0f},{m.vy:+.0f}) speed {m.speed:.0f}px/s",
              f"accel {m.acc:.0f}px/s^2",
              f"Pinch dist {eng.pinch_d:.1f}px (grab<={c.grab_th:.0f}, release>={c.release_th:.0f}) "
              f"{'PINCHED' if eng.pinch.pinching else 'open'}" if eng.pinch_d is not None
              else "Pinch dist: -",
              f"Collision: area {eng.overlap.area:.0f}px^2  {eng.overlap.pct:.1f}%"
              + (f" with R{eng.overlap_with.id}" if eng.overlap_with and eng.overlap.pct > 0 else ""),
              f"Snap {'ON' if c.snap_on else 'OFF'} cell {c.cell}px  grid cell {eng.grid_cell}  "
              f"snap err {eng.snap_err:.1f}px",
              f"Dwell timer {eng.t_dwell:.2f}s / {c.dwell_time:.1f}s"]
    ph = 18 * len(lines) + 10
    overlay = img.copy()
    cv2.rectangle(overlay, (5, 5), (520, 5 + ph), (0, 0, 0), cv2.FILLED)
    cv2.addWeighted(overlay, 0.6, img, 0.4, 0, dst=img)
    for i, line in enumerate(lines):
        put(img, line, (12, 24 + 18 * i), (0, 255, 0), 0.47)

    if eng.state == State.COLLISION:
        put(img, f"COLLISION WARNING: {eng.overlap.pct:.0f}% overlap", (W // 2 - 190, 40), (0, 0, 255), 0.8, 2)
    if eng.message and now < eng.message_until:
        put(img, eng.message, (W // 2 - 190, 75), (0, 200, 255), 0.7, 2)
    put(img, "p:physics  1:gravity  2:forcefield  3:damping  c:new  g:snap  [ ]:grid  u:unlock  s:shot  q:quit", (12, H - 12), (200, 200, 200), 0.5)


def main():
    cap, idx = open_camera()
    if cap is None:
        print("ERROR: no working camera found (tried indices 0-3). Check that it is connected "
              "and not used by another app.")
        return 1
    print(f"Camera index {idx} opened.")
    detector = HandDetector(detectionCon=0.8, maxHands=1)
    eng = DragEngine()
    fails, last_t, fps = 0, time.perf_counter(), 0.0
    cv2.namedWindow("Lab 2 - V08")
    try:
        while True:
            ok, img = cap.read()
            if not ok:
                fails += 1
                if fails > 30:
                    print("Camera stopped delivering frames. Exiting.")
                    break
                continue
            fails = 0
            img = cv2.flip(img, 1)                          
            H, W = img.shape[:2]
            try:
                hands, img = detector.findHands(img, flipType=False)
            except Exception as e:                          
                print("hand detection error:", e)
                hands = []
            now = time.perf_counter()
            if now - last_t > 0:
                fps = 0.9 * fps + 0.1 / (now - last_t)
            last_t = now
            eng.update(extract_sample(hands, W, H), now, W, H)
            draw(img, eng, now, fps)
            cv2.imshow("Lab 2 - V08", img)

            key = cv2.waitKey(1) & 0xFF
            if key == ord("q"):
                break
            elif key == ord("c"):
                eng.W, eng.H = W, H
                eng.add_rect(now)
            elif key == ord("g"):
                eng.toggle_snap(now)
            elif key == ord("["):
                eng.change_cell(-1, now)
            elif key == ord("]"):
                eng.change_cell(+1, now)
            elif key == ord("u"):
                eng.unlock_all(now)
            elif key == ord("s"):
                os.makedirs("screenshots", exist_ok=True)
                path = os.path.join("screenshots", time.strftime("shot_%H%M%S.png"))
                cv2.imwrite(path, img)
                eng.say(f"Saved {path}", now)
            elif key == ord("p"):
                eng.cfg.physics_enabled = not eng.cfg.physics_enabled
                eng.say(f"Physics {'ON' if eng.cfg.physics_enabled else 'OFF'}", now)
            elif key == ord("1"):
                eng.cfg.gravity = 980.0 if eng.cfg.gravity == 0 else 0
                eng.say(f"Gravity {'ON' if eng.cfg.gravity > 0 else 'OFF'}", now)
            elif key == ord("2"):
                eng.cfg.attractor_strength = 500000.0 if eng.cfg.attractor_strength <= 0 else -500000.0
                mode = "ATTRACT" if eng.cfg.attractor_strength > 0 else "REPEL"
                eng.say(f"Force Field: {mode}", now)
            elif key == ord("3"):
                eng.cfg.damping = 0.98 if eng.cfg.damping < 0.98 else 0.85
                eng.say(f"Damping/Friction: {eng.cfg.damping:.2f}", now)
    finally:
        cap.release()
        cv2.destroyAllWindows()
        eng.save_log("lab2_events.log")
        print("Clean exit. State-change log saved to lab2_events.log")
    return 0


if __name__ == "__main__":
    sys.exit(main())